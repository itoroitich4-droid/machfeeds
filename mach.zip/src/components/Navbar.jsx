
import { useState } from 'react'
import { Link, NavLink } from 'react-router-dom'
import { Menu, X } from 'lucide-react'

const navLinks = [
  { name: 'Home', path: '/' },
  { name: 'About Us', path: '/about' },
  { name: 'Products', path: '/products' },
  { name: 'Raw Materials', path: '/raw-materials' },
  { name: 'Services', path: '/services' },
  { name: 'Our Location', path: '/location' },
  { name: 'Contact Us', path: '/contact' },
]

function Navbar() {
  const [menuOpen, setMenuOpen] = useState(false)

  return (
    <header className="sticky top-0 z-50 bg-white shadow-sm">
      <div className="container flex min-h-20 items-center justify-between">
        <Link to="/" className="flex items-center gap-2">
          <div className="flex h-11 w-11 items-center justify-center rounded-lg bg-brand text-xl font-bold text-white">
            M
          </div>
          <div>
            <h1 className="text-xl font-extrabold tracking-wide text-brand">
              MACH FEEDS
            </h1>
            <p className="text-xs tracking-widest text-gray-500">
              QUALITY ANIMAL NUTRITION
            </p>
          </div>
        </Link>

        <nav className="hidden items-center gap-6 lg:flex">
          {navLinks.map((link) => (
            <NavLink
              key={link.path}
              to={link.path}
              className={({ isActive }) =>
                `text-sm font-semibold transition-colors ${
                  isActive
                    ? 'text-harvest'
                    : 'text-gray-700 hover:text-harvest'
                }`
              }
            >
              {link.name}
            </NavLink>
          ))}
        </nav>

        <button
          className="rounded-lg p-2 text-brand lg:hidden"
          onClick={() => setMenuOpen(!menuOpen)}
          aria-label="Toggle navigation"
          aria-expanded={menuOpen}
        >
          {menuOpen ? <X size={26} /> : <Menu size={26} />}
        </button>
      </div>

      {menuOpen && (
        <nav className="border-t border-gray-100 bg-white px-6 py-4 lg:hidden">
          {navLinks.map((link) => (
            <NavLink
              key={link.path}
              to={link.path}
              onClick={() => setMenuOpen(false)}
              className={({ isActive }) =>
                `block py-3 text-sm font-semibold ${
                  isActive ? 'text-harvest' : 'text-gray-700'
                }`
              }
            >
              {link.name}
            </NavLink>
          ))}
        </nav>
      )}
    </header>
  )
}

export default Navbar
