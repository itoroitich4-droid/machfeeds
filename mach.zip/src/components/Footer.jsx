
import { Link } from 'react-router-dom'
import { MapPin, Phone, Mail } from 'lucide-react'

function Footer() {
  return (
    <footer className="bg-brand text-white">
      <div className="container grid gap-10 py-14 md:grid-cols-2 lg:grid-cols-4">
        <div>
          <h2 className="mb-4 text-2xl font-extrabold tracking-wide">
            MACH FEEDS
          </h2>
          <p className="mb-4 text-sm leading-7 text-gray-300">
            Quality animal nutrition for healthier livestock and better
            productivity. Think of quality? Think Mach Feeds.
          </p>
          <p className="text-sm font-semibold text-harvest">
            Quality You Can Trust.
          </p>
        </div>

        <div>
          <h3 className="mb-5 text-lg font-bold">Quick Links</h3>
          <ul className="space-y-3 text-sm text-gray-300">
            <li><Link to="/" className="hover:text-harvest">Home</Link></li>
            <li><Link to="/about" className="hover:text-harvest">About Us</Link></li>
            <li><Link to="/products" className="hover:text-harvest">Our Products</Link></li>
            <li><Link to="/services" className="hover:text-harvest">Our Services</Link></li>
            <li><Link to="/contact" className="hover:text-harvest">Contact Us</Link></li>
          </ul>
        </div>

        <div>
          <h3 className="mb-5 text-lg font-bold">Our Products</h3>
          <ul className="space-y-3 text-sm text-gray-300">
            <li>Dairy Feeds</li>
            <li>Poultry Feeds</li>
            <li>Pig Feeds</li>
            <li>Fish Feeds</li>
            <li>Rabbit Feeds</li>
            <li>Livestock Supplements</li>
          </ul>
        </div>

        <div>
          <h3 className="mb-5 text-lg font-bold">Get In Touch</h3>
          <ul className="space-y-4 text-sm text-gray-300">
            <li className="flex items-start gap-3">
              <MapPin size={19} className="mt-1 shrink-0 text-harvest" />
              <span>Kenya</span>
            </li>
            <li className="flex items-center gap-3">
              <Phone size={19} className="shrink-0 text-harvest" />
              <a href="tel:+254721325676" className="hover:text-harvest">
                +254 721 325 676
              </a>
            </li>
            <li className="flex items-center gap-3">
              <Mail size={19} className="shrink-0 text-harvest" />
              <a href="mailto:info@machfeeds.com" className="hover:text-harvest">
                info@machfeeds.com
              </a>
            </li>
          </ul>
        </div>
      </div>

      <div className="border-t border-white/15">
        <div className="container flex flex-col justify-between gap-3 py-5 text-sm text-gray-300 md:flex-row">
          <p>© {new Date().getFullYear()} Mach Feeds. All rights reserved.</p>
          <p>Quality Animal Nutrition.</p>
        </div>
      </div>
    </footer>
  )
}

export default Footer
