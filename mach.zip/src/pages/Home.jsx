
import { Link } from 'react-router-dom'
import {
  ArrowRight,
  CheckCircle,
  Truck,
  Award,
  Leaf,
} from 'lucide-react'

const categories = [
  {
    name: 'Dairy Feeds',
    description: 'Quality nutrition formulated to support healthy dairy animals and milk production.',
    icon: '🐄',
  },
  {
    name: 'Poultry Feeds',
    description: 'Balanced nutrition for healthier birds, growth and egg production.',
    icon: '🐔',
  },
  {
    name: 'Pig Feeds',
    description: 'Nutritionally balanced feeds for different stages of pig production.',
    icon: '🐖',
  },
  {
    name: 'Fish Feeds',
    description: 'Quality feed solutions designed to support fish growth and productivity.',
    icon: '🐟',
  },
]

const reasons = [
  {
    icon: <Award size={30} />,
    title: 'Quality You Can Trust',
    description: 'We are committed to delivering quality animal nutrition solutions.',
  },
  {
    icon: <Leaf size={30} />,
    title: 'Nutritional Solutions',
    description: 'Our products are designed to support livestock health and productivity.',
  },
  {
    icon: <Truck size={30} />,
    title: 'Reliable Distribution',
    description: 'We support customers through product distribution and delivery services.',
  },
]

function Home() {
  return (
    <>
      <section className="relative overflow-hidden bg-brand text-white">
        <div className="absolute inset-0 bg-gradient-to-r from-brand via-brand/95 to-brand-dark" />

        <div className="container relative grid min-h-[570px] items-center gap-10 py-20 lg:grid-cols-2">
          <div className="max-w-2xl">
            <p className="mb-5 font-semibold uppercase tracking-[0.2em] text-harvest">
              Quality Animal Nutrition
            </p>

            <h1 className="mb-6 text-4xl font-extrabold leading-tight md:text-6xl">
              Better Nutrition.
              <span className="block text-harvest">
                Better Productivity.
              </span>
            </h1>

            <p className="mb-8 max-w-xl text-lg leading-8 text-gray-200">
              Supporting livestock farmers with quality animal feeds,
              nutritional solutions and reliable services.
            </p>

            <div className="flex flex-wrap gap-4">
              <Link
                to="/products"
                className="inline-flex items-center gap-2 rounded-md bg-harvest px-7 py-4 font-bold text-brand transition hover:bg-white"
              >
                Explore Our Products
                <ArrowRight size={19} />
              </Link>

              <Link
                to="/contact"
                className="rounded-md border border-white px-7 py-4 font-bold transition hover:bg-white hover:text-brand"
              >
                Contact Us
              </Link>
            </div>
          </div>

          <div className="flex min-h-[300px] items-center justify-center rounded-2xl border border-white/10 bg-white/5 p-10 text-center backdrop-blur-sm">
            <div>
              <div className="mb-5 text-8xl">🌾</div>
              <p className="text-2xl font-bold">Think Quality?</p>
              <p className="mt-2 text-3xl font-extrabold text-harvest">
                Think Mach Feeds.
              </p>
              <p className="mt-4 text-sm text-gray-300">
                Quality nutrition for productive livestock.
              </p>
            </div>
          </div>
        </div>
      </section>

      <section className="section-padding bg-white">
        <div className="container">
          <div className="mx-auto mb-12 max-w-2xl text-center">
            <p className="mb-3 font-bold uppercase tracking-widest text-harvest">
              What We Offer
            </p>
            <h2 className="mb-4 text-3xl font-extrabold text-brand md:text-4xl">
              Animal Nutrition Solutions
            </h2>
            <p className="leading-7 text-gray-600">
              Explore our range of animal feeds developed to support
              different livestock production needs.
            </p>
          </div>

          <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
            {categories.map((category) => (
              <div
                key={category.name}
                className="rounded-xl border border-gray-100 bg-white p-7 shadow-sm transition hover:-translate-y-1 hover:shadow-lg"
              >
                <div className="mb-5 text-5xl">{category.icon}</div>
                <h3 className="mb-3 text-xl font-bold text-brand">
                  {category.name}
                </h3>
                <p className="mb-5 text-sm leading-7 text-gray-600">
                  {category.description}
                </p>
                <Link
                  to="/products"
                  className="inline-flex items-center gap-2 font-bold text-harvest hover:text-brand"
                >
                  View Products <ArrowRight size={17} />
                </Link>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="section-padding bg-gray-50">
        <div className="container grid items-center gap-12 lg:grid-cols-2">
          <div>
            <p className="mb-3 font-bold uppercase tracking-widest text-harvest">
              About Mach Feeds
            </p>
            <h2 className="mb-6 text-3xl font-extrabold leading-tight text-brand md:text-4xl">
              Supporting Farmers Through Quality Nutrition
            </h2>
            <p className="mb-5 leading-8 text-gray-600">
              Mach Feeds is an animal feeds manufacturer committed to
              providing nutritional solutions for livestock farmers.
              We aim to support healthier animals and improved
              agricultural productivity.
            </p>
            <p className="mb-7 leading-8 text-gray-600">
              From animal feeds to raw materials and consultation,
              we provide products and services that support the
              livestock industry.
            </p>
            <Link
              to="/about"
              className="inline-flex items-center gap-2 rounded-md bg-brand px-7 py-4 font-bold text-white transition hover:bg-harvest"
            >
              Learn More About Us <ArrowRight size={18} />
            </Link>
          </div>

          <div className="rounded-2xl bg-brand p-9 text-white md:p-12">
            <h3 className="mb-8 text-2xl font-bold">
              Why Choose Mach Feeds?
            </h3>

            <div className="space-y-8">
              {reasons.map((reason) => (
                <div key={reason.title} className="flex gap-5">
                  <div className="text-harvest">{reason.icon}</div>
                  <div>
                    <h4 className="mb-2 font-bold">{reason.title}</h4>
                    <p className="text-sm leading-7 text-gray-300">
                      {reason.description}
                    </p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      <section className="section-padding bg-harvest">
        <div className="container flex flex-col items-center justify-between gap-7 text-center md:flex-row md:text-left">
          <div>
            <h2 className="mb-3 text-3xl font-extrabold text-brand">
              Let's Grow Together
            </h2>
            <p className="text-brand/80">
              Talk to us about your animal nutrition requirements.
            </p>
          </div>

          <Link
            to="/contact"
            className="inline-flex items-center gap-2 rounded-md bg-brand px-8 py-4 font-bold text-white transition hover:bg-white hover:text-brand"
          >
            Get In Touch <CheckCircle size={19} />
          </Link>
        </div>
      </section>
    </>
  )
}

export default Home
