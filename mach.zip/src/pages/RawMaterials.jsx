
import { Link } from 'react-router-dom'
import { ArrowRight } from 'lucide-react'

const materials = [
  {
    name: 'Omena',
    description: 'A fish-based ingredient used in animal feed formulations.',
    icon: '🐟',
  },
  {
    name: 'Cottonseed Cake',
    description: 'An agricultural by-product used as an ingredient in livestock feeds.',
    icon: '🌱',
  },
  {
    name: 'Sunflower Cake',
    description: 'A plant-based feed ingredient obtained from sunflower processing.',
    icon: '🌻',
  },
  {
    name: 'Maize Germ',
    description: 'A maize processing ingredient used in animal feed production.',
    icon: '🌽',
  },
  {
    name: 'Soybean Meal',
    description: 'A plant-based protein ingredient used in animal nutrition.',
    icon: '🫘',
  },
  {
    name: 'Wheat Bran and Pollard',
    description: 'Wheat milling by-products used in livestock feed formulations.',
    icon: '🌾',
  },
  {
    name: 'Molasses',
    description: 'A sugar-industry by-product used in animal feed formulations.',
    icon: '🍯',
  },
    {
    name: 'Canola Meal',
    description: 'A plant-based ingredient obtained from canola seed processing and used in animal feed formulations.',
    icon: '🌿',
  },
  {
    name: 'Copra Meal',
    description: 'A coconut processing by-product used as an ingredient in animal feed formulations.',
    icon: '🥥',
  },
]

function RawMaterials() {
  return (
    <>
      <section className="bg-brand py-20 text-white">
        <div className="container">
          <p className="mb-4 font-bold uppercase tracking-widest text-harvest">
            Feed Ingredients
          </p>
          <h1 className="mb-5 text-4xl font-extrabold md:text-5xl">
            Raw Materials
          </h1>
          <p className="max-w-2xl text-lg leading-8 text-gray-200">
            Explore ingredients used in animal nutrition and feed
            manufacturing.
          </p>
        </div>
      </section>

      <section className="section-padding">
        <div className="container">
          <div className="mb-12 max-w-2xl">
            <h2 className="mb-4 text-3xl font-extrabold text-brand">
              Ingredients for Animal Nutrition
            </h2>
            <p className="leading-7 text-gray-600">
              We work with a range of agricultural ingredients and
              feed materials. Contact our team to confirm availability,
              quality specifications and supply arrangements.
            </p>
          </div>

          <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
            {materials.map((material) => (
              <article
                key={material.name}
                className="rounded-xl border border-gray-100 bg-white p-8 shadow-sm transition hover:-translate-y-1 hover:shadow-lg"
              >
                <div className="mb-5 text-5xl">{material.icon}</div>
                <h3 className="mb-3 text-xl font-bold text-brand">
                  {material.name}
                </h3>
                <p className="mb-6 text-sm leading-7 text-gray-600">
                  {material.description}
                </p>
                <Link
                  to="/contact"
                  className="inline-flex items-center gap-2 font-bold text-harvest hover:text-brand"
                >
                  Make an Enquiry <ArrowRight size={18} />
                </Link>
              </article>
            ))}
          </div>
        </div>
      </section>
    </>
  )
}

export default RawMaterials
