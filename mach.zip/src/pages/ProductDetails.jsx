import { useParams, Link } from 'react-router-dom'
import { ArrowLeft, MessageCircle } from 'lucide-react'

const products = {
  'dairy-meal-high-yield': {
    name: 'Dairy Meal High Yield',
    category: 'Dairy Feed',
    description: 'Animal feed for dairy cattle.',
  },
  'layers-mash-complete-meal': {
    name: 'Layers Mash Complete Meal',
    category: 'Poultry Feed',
    description: 'Complete feed for laying birds.',
  },
  'growers-mash': {
    name: 'Growers Mash',
    category: 'Poultry Feed',
    description: 'Feed for growing poultry.',
  },
  'chick-mash': {
    name: 'Chick Mash',
    category: 'Poultry Feed',
    description: 'Feed for young chicks.',
  },
  'broilers-starter': {
    name: 'Broilers Starter',
    category: 'Poultry Feed',
    description: 'Starter feed for broiler chickens.',
  },
  'broilers-finisher': {
    name: 'Broilers Finisher',
    category: 'Poultry Feed',
    description: 'Finisher feed for broiler chickens.',
  },
  'sow-and-weaner-starter': {
    name: 'Sow and Weaner Starter',
    category: 'Pig Feed',
    description: 'Feed for sows and weaner pigs.',
  },
  'pig-finisher': {
    name: 'Pig Finisher',
    category: 'Pig Feed',
    description: 'Feed for finishing pigs.',
  },
  'dog-meal': {
    name: 'Dog Meal',
    category: 'Dog Feed',
    description: 'Animal feed formulated for dogs.',
  },
  'mach-rabbit': {
    name: 'Mach Rabbit',
    category: 'Rabbit Feed',
    description: 'Feed for rabbits.',
  },
  'mach-samaki': {
    name: 'Mach Samaki',
    category: 'Fish Feed',
    description: 'Feed for fish.',
  },
  'sheep-and-goat-complete-meal': {
    name: 'Sheep and Goat Complete Meal',
    category: 'Sheep and Goat Feed',
    description: 'Complete feed for sheep and goats.',
  },
}

function ProductDetails() {
  const { slug } = useParams()
  const product = products[slug]

  if (!product) {
    return (
      <section className="container py-20 text-center">
        <h1 className="mb-4 text-3xl font-bold">
          Product Not Found
        </h1>
        <Link to="/products" className="font-semibold text-amber-600">
          Return to Products
        </Link>
      </section>
    )
  }

  const message = encodeURIComponent(
    `Hello Mach Feeds, I would like to enquire about ${product.name}.`
  )

  return (
    <section className="bg-white py-16">
      <div className="container">
        <Link
          to="/products"
          className="mb-10 inline-flex items-center gap-2 font-semibold text-gray-600 hover:text-amber-600"
        >
          <ArrowLeft size={18} />
          Back to Products
        </Link>

        <div className="mx-auto max-w-3xl rounded-2xl border border-gray-200 p-8 shadow-sm md:p-12">
          <p className="mb-3 font-semibold uppercase tracking-widest text-amber-600">
            {product.category}
          </p>

          <h1 className="mb-6 text-3xl font-bold text-slate-900 md:text-4xl">
            {product.name}
          </h1>

          <p className="mb-8 leading-7 text-gray-600">
            {product.description}
          </p>

          <a
            href={`https://wa.me/254721325676?text=${message}`}
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center gap-2 rounded-lg bg-green-700 px-6 py-3 font-semibold text-white transition hover:bg-green-800"
          >
            <MessageCircle size={19} />
            Enquire on WhatsApp
          </a>
        </div>
      </div>
    </section>
  )
}

export default ProductDetails