
import {
  Truck,
  Users,
  Store,
  FlaskConical,
  Handshake,
  ArrowRight,
} from 'lucide-react'
import { Link } from 'react-router-dom'

const services = [
  {
    title: 'Animal Nutrition Consultation',
    description:
      'Guidance and consultation to help farmers make informed animal nutrition decisions.',
    icon: <Users size={34} />,
  },
  {
    title: 'Product Distribution and Delivery',
    description:
      'Distribution and delivery support to help customers access Mach Feeds products.',
    icon: <Truck size={34} />,
  },
  {
    title: 'Distributorship Opportunities',
    description:
      'Opportunities for businesses interested in distributing Mach Feeds products.',
    icon: <Store size={34} />,
  },
  {
    title: 'Feed Supplements',
    description:
      'Access to nutritional supplements that support animal feeding programmes.',
    icon: <FlaskConical size={34} />,
  },
  {
    title: 'Livestock Nutrition Support',
    description:
      'Support for farmers seeking appropriate feed solutions for their livestock.',
    icon: <Handshake size={34} />,
  },
]

function Services() {
  return (
    <>
      <section className="bg-brand py-20 text-white">
        <div className="container">
          <p className="mb-4 font-bold uppercase tracking-widest text-harvest">
            How We Help
          </p>
          <h1 className="mb-5 text-4xl font-extrabold md:text-5xl">
            Our Services
          </h1>
          <p className="max-w-2xl text-lg leading-8 text-gray-200">
            More than animal feeds. We support farmers, distributors
            and businesses through our range of services.
          </p>
        </div>
      </section>

      <section className="section-padding">
        <div className="container">
          <div className="mb-12 max-w-2xl">
            <h2 className="mb-4 text-3xl font-extrabold text-brand">
              Supporting Your Business
            </h2>
            <p className="leading-7 text-gray-600">
              Our services are intended to make it easier for customers
              to access animal nutrition products and related support.
              Contact us to confirm the services available for your needs.
            </p>
          </div>

          <div className="grid gap-7 sm:grid-cols-2 lg:grid-cols-3">
            {services.map((service) => (
              <article
                key={service.title}
                className="rounded-xl border border-gray-100 bg-white p-8 shadow-sm transition hover:-translate-y-1 hover:shadow-lg"
              >
                <div className="mb-6 flex h-16 w-16 items-center justify-center rounded-xl bg-brand text-harvest">
                  {service.icon}
                </div>

                <h3 className="mb-4 text-xl font-bold text-brand">
                  {service.title}
                </h3>

                <p className="mb-6 text-sm leading-7 text-gray-600">
                  {service.description}
                </p>

                <Link
                  to="/contact"
                  className="inline-flex items-center gap-2 font-bold text-harvest hover:text-brand"
                >
                  Enquire Now <ArrowRight size={18} />
                </Link>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className="bg-gray-50 py-16">
        <div className="container text-center">
          <h2 className="mb-4 text-3xl font-extrabold text-brand">
            Need Assistance?
          </h2>
          <p className="mx-auto mb-7 max-w-xl leading-7 text-gray-600">
            Get in touch with Mach Feeds to discuss your animal
            nutrition and business requirements.
          </p>
          <Link
            to="/contact"
            className="inline-flex items-center gap-2 rounded-md bg-brand px-8 py-4 font-bold text-white transition hover:bg-harvest"
          >
            Contact Our Team <ArrowRight size={18} />
          </Link>
        </div>
      </section>
    </>
  )
}

export default Services
