import { Link } from 'react-router-dom'
import { ArrowRight } from 'lucide-react'

const products = [
  {
    name: 'Dairy Meal High Yield',
    category: 'Dairy Feed',
    slug: 'dairy-meal-high-yield',
    description: 'Animal feed formulated for dairy cattle.',
  },
  {
    name: 'Layers Mash Complete Meal',
    category: 'Poultry Feed',
    slug: 'layers-mash-complete-meal',
    description: 'Complete feed for laying birds.',
  },
  {
    name: 'Growers Mash',
    category: 'Poultry Feed',
    slug: 'growers-mash',
    description: 'Feed for growing poultry.',
  },
  {
    name: 'Chick Mash',
    category: 'Poultry Feed',
    slug: 'chick-mash',
    description: 'Feed for young chicks.',
  },
  {
    name: 'Broilers Starter',
    category: 'Poultry Feed',
    slug: 'broilers-starter',
    description: 'Starter feed for broiler chickens.',
  },
  {
    name: 'Broilers Finisher',
    category: 'Poultry Feed',
    slug: 'broilers-finisher',
    description: 'Finisher feed for broiler chickens.',
  },
  {
    name: 'Sow and Weaner Starter',
    category: 'Pig Feed',
    slug: 'sow-and-weaner-starter',
    description: 'Feed for sows and weaner pigs.',
  },
  {
    name: 'Pig Finisher',
    category: 'Pig Feed',
    slug: 'pig-finisher',
    description: 'Feed for finishing pigs.',
  },
  {
    name: 'Dog Meal',
    category: 'Dog Feed',
    slug: 'dog-meal',
    description: 'Feed formulated for dogs.',
  },
  {
    name: 'Mach Rabbit',
    category: 'Rabbit Feed',
    slug: 'mach-rabbit',
    description: 'Feed for rabbits.',
  },
  {
    name: 'Mach Samaki',
    category: 'Fish Feed',
    slug: 'mach-samaki',
    description: 'Feed for fish.',
  },
  {
    name: 'Sheep and Goat Complete Meal',
    category: 'Sheep and Goat Feed',
    slug: 'sheep-and-goat-complete-meal',
    description: 'Complete feed for sheep and goats.',
  },
]

function Products() {
  return (
    <section className="bg-white py-16">
      <div className="container">
        <div className="mb-12 text-center">
          <p className="mb-3 font-semibold uppercase tracking-widest text-amber-600">
            Our Products
          </p>

          <h1 className="mb-4 text-3xl font-bold text-slate-900 md:text-5xl">
            Quality Animal Feeds
          </h1>

          <p className="mx-auto max-w-2xl text-gray-600">
            Explore the Mach Feeds range of animal nutrition products
            developed for different livestock and poultry needs.
          </p>
        </div>

        <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
          {products.map((product) => (
            <article
              key={product.slug}
              className="rounded-xl border border-gray-200 bg-white p-6 shadow-sm transition hover:-translate-y-1 hover:shadow-lg"
            >
              <p className="mb-3 text-sm font-semibold uppercase tracking-wide text-amber-600">
                {product.category}
              </p>

              <h2 className="mb-3 text-xl font-bold text-slate-900">
                {product.name}
              </h2>

              <p className="mb-6 text-sm leading-6 text-gray-600">
                {product.description}
              </p>

              <Link
                to={`/products/${product.slug}`}
                className="inline-flex items-center gap-2 font-semibold text-slate-900 transition hover:text-amber-600"
              >
                View Product
                <ArrowRight size={17} />
              </Link>
            </article>
          ))}
        </div>
      </div>
    </section>
  )
}

export default Products