import { Link } from 'react-router-dom'
import { Home, ArrowLeft } from 'lucide-react'

function NotFound() {
  return (
    <section className="flex min-h-[70vh] items-center justify-center bg-gray-50 px-4">
      <div className="max-w-xl text-center">
        <p className="mb-3 text-sm font-bold uppercase tracking-widest text-amber-600">
          Error 404
        </p>

        <h1 className="mb-4 text-4xl font-bold text-slate-900 md:text-6xl">
          Page Not Found
        </h1>

        <p className="mb-8 text-gray-600">
          Sorry, the page you're looking for doesn't exist or may have been moved.
        </p>

        <Link
          to="/"
          className="inline-flex items-center gap-2 rounded-lg bg-slate-900 px-6 py-3 font-semibold text-white transition hover:bg-amber-600"
        >
          <Home size={18} />
          Back to Home
        </Link>
      </div>
    </section>
  )
}

export default NotFound