
import { MapPin, Navigation, Phone } from 'lucide-react'

function Location() {
  const googleMapsUrl =
    'https://www.google.com/maps/search/?api=1&query=Mach%20Feeds%2C%20Thika%2C%20Kenya&query_place_id=ChIJrxpCJIVOLxgRfO3wHaLWSQ0'

  return (
    <>
      <section className="bg-brand py-20 text-white">
        <div className="container">
          <p className="mb-4 font-bold uppercase tracking-widest text-harvest">
            Find Us
          </p>
          <h1 className="mb-5 text-4xl font-extrabold md:text-5xl">
            Our Location
          </h1>
          <p className="max-w-2xl text-lg leading-8 text-gray-200">
            Visit Mach Feeds at our premises in Thika, Kenya.
          </p>
        </div>
      </section>

      <section className="section-padding">
        <div className="container grid gap-10 lg:grid-cols-2">
          <div>
            <p className="mb-3 font-bold uppercase tracking-widest text-harvest">
              Visit Mach Feeds
            </p>

            <h2 className="mb-6 text-3xl font-extrabold text-brand">
              We'd Be Happy to Hear From You
            </h2>

            <p className="mb-8 leading-8 text-gray-600">
              Find our business premises in Thika and get directions
              directly through Google Maps.
            </p>

            <div className="mb-6 flex gap-4 rounded-xl bg-gray-50 p-6">
              <MapPin className="shrink-0 text-harvest" size={28} />
              <div>
                <h3 className="mb-2 font-bold text-brand">
                  Our Premises
                </h3>
                <p className="text-sm leading-7 text-gray-600">
                  Behind The Mathai Supermarket Stores, near the
                  Hindu Temple, Thika, Kenya.
                </p>
              </div>
            </div>

            <div className="mb-6 flex gap-4 rounded-xl bg-gray-50 p-6">
              <Phone className="shrink-0 text-harvest" size={28} />
              <div>
                <h3 className="mb-2 font-bold text-brand">
                  Call Us
                </h3>
                <a
                  href="tel:+254721325676"
                  className="text-sm text-gray-600 hover:text-harvest"
                >
                  +254 721 325 676
                </a>
              </div>
            </div>

            <a
              href={googleMapsUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-2 rounded-md bg-brand px-7 py-4 font-bold text-white transition hover:bg-harvest"
            >
              <Navigation size={18} />
              Get Directions
            </a>
          </div>

          <div className="flex min-h-[350px] flex-col items-center justify-center rounded-2xl border border-gray-200 bg-gray-50 p-8 text-center">
            <MapPin size={55} className="mb-5 text-harvest" />

            <h3 className="mb-3 text-2xl font-bold text-brand">
              Mach Feeds on Google Maps
            </h3>

            <p className="mb-6 max-w-sm leading-7 text-gray-600">
              Find our actual business listing and view our location
              on Google Maps.
            </p>

            <a
              href={googleMapsUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-2 rounded-md bg-brand px-7 py-4 font-bold text-white transition hover:bg-harvest"
            >
              <MapPin size={18} />
              View Mach Feeds on Maps
            </a>
          </div>
        </div>
      </section>
    </>
  )
}

export default Location
