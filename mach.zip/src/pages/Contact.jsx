
import { useState } from 'react'
import { Mail, Phone, MapPin, MessageCircle, Send } from 'lucide-react'

function Contact() {
  const [form, setForm] = useState({
    name: '',
    email: '',
    subject: '',
    message: '',
  })

  const handleChange = (event) => {
    setForm({
      ...form,
      [event.target.name]: event.target.value,
    })
  }

  const handleSubmit = (event) => {
    event.preventDefault()

    const subject = encodeURIComponent(form.subject)
    const body = encodeURIComponent(
      `Name: ${form.name}\nEmail: ${form.email}\n\n${form.message}`,
    )

    window.location.href =
      `mailto:info@machfeeds.com?subject=${subject}&body=${body}`
  }

  return (
    <>
      <section className="bg-brand py-20 text-white">
        <div className="container">
          <p className="mb-4 font-bold uppercase tracking-widest text-harvest">
            Get In Touch
          </p>
          <h1 className="mb-5 text-4xl font-extrabold md:text-5xl">
            Contact Mach Feeds
          </h1>
          <p className="max-w-2xl text-lg leading-8 text-gray-200">
            Have a question about our products or services?
            We'd be happy to hear from you.
          </p>
        </div>
      </section>

      <section className="section-padding">
        <div className="container grid gap-12 lg:grid-cols-2">
          <div>
            <h2 className="mb-5 text-3xl font-extrabold text-brand">
              Let's Talk
            </h2>
            <p className="mb-9 leading-8 text-gray-600">
              Reach out to our team for product enquiries, distribution
              opportunities, raw materials and other business matters.
            </p>

            <div className="space-y-6">
              <div className="flex gap-4">
                <div className="flex h-12 w-12 shrink-0 items-center justify-center rounded-lg bg-brand text-harvest">
                  <Phone size={23} />
                </div>
                <div>
                  <h3 className="font-bold text-brand">Phone</h3>
                  <a
                    href="tel:+254721325676"
                    className="text-gray-600 hover:text-harvest"
                  >
                    +254 721 325 676
                  </a>
                </div>
              </div>

              <div className="flex gap-4">
                <div className="flex h-12 w-12 shrink-0 items-center justify-center rounded-lg bg-brand text-harvest">
                  <Mail size={23} />
                </div>
                <div>
                  <h3 className="font-bold text-brand">Email</h3>
                  <a
                    href="mailto:info@machfeeds.com"
                    className="text-gray-600 hover:text-harvest"
                  >
                    info@machfeeds.com
                  </a>
                </div>
              </div>

              <div className="flex gap-4">
                <div className="flex h-12 w-12 shrink-0 items-center justify-center rounded-lg bg-brand text-harvest">
                  <MapPin size={23} />
                </div>
                <div>
                  <h3 className="font-bold text-brand">Location</h3>
                  <p className="text-gray-600">
                    Contact us for our verified physical address.
                  </p>
                </div>
              </div>
            </div>

            <a
              href="https://wa.me/254721325676"
              target="_blank"
              rel="noreferrer"
              className="mt-9 inline-flex items-center gap-2 rounded-md bg-green-600 px-7 py-4 font-bold text-white transition hover:bg-green-700"
            >
              <MessageCircle size={20} />
              Chat on WhatsApp
            </a>
          </div>

          <div className="rounded-2xl bg-gray-50 p-8 md:p-10">
            <h2 className="mb-7 text-2xl font-bold text-brand">
              Send Us a Message
            </h2>

            <form onSubmit={handleSubmit} className="space-y-5">
              <div>
                <label className="mb-2 block text-sm font-semibold text-gray-700">
                  Your Name
                </label>
                <input
                  type="text"
                  name="name"
                  value={form.name}
                  onChange={handleChange}
                  required
                  className="w-full rounded-md border border-gray-300 bg-white px-4 py-3 outline-none focus:border-harvest"
                  placeholder="Enter your name"
                />
              </div>

              <div>
                <label className="mb-2 block text-sm font-semibold text-gray-700">
                  Email Address
                </label>
                <input
                  type="email"
                  name="email"
                  value={form.email}
                  onChange={handleChange}
                  required
                  className="w-full rounded-md border border-gray-300 bg-white px-4 py-3 outline-none focus:border-harvest"
                  placeholder="Enter your email"
                />
              </div>

              <div>
                <label className="mb-2 block text-sm font-semibold text-gray-700">
                  Subject
                </label>
                <input
                  type="text"
                  name="subject"
                  value={form.subject}
                  onChange={handleChange}
                  required
                  className="w-full rounded-md border border-gray-300 bg-white px-4 py-3 outline-none focus:border-harvest"
                  placeholder="What is your enquiry about?"
                />
              </div>

              <div>
                <label className="mb-2 block text-sm font-semibold text-gray-700">
                  Message
                </label>
                <textarea
                  name="message"
                  value={form.message}
                  onChange={handleChange}
                  required
                  rows="5"
                  className="w-full rounded-md border border-gray-300 bg-white px-4 py-3 outline-none focus:border-harvest"
                  placeholder="Write your message here..."
                />
              </div>

              <button
                type="submit"
                className="inline-flex w-full items-center justify-center gap-2 rounded-md bg-brand px-7 py-4 font-bold text-white transition hover:bg-harvest"
              >
                Send Message <Send size={18} />
              </button>

              <p className="text-xs leading-5 text-gray-500">
                Your default email application will open with your
                message prepared. The website does not store or send
                form submissions directly.
              </p>
            </form>
          </div>
        </div>
      </section>
    </>
  )
}

export default Contact
