
import { Award, Target, Eye, HeartHandshake } from 'lucide-react'

function About() {
  return (
    <>
      <section className="bg-brand py-20 text-white">
        <div className="container">
          <p className="mb-4 font-bold uppercase tracking-widest text-harvest">
            Get to Know Us
          </p>
          <h1 className="mb-5 text-4xl font-extrabold md:text-5xl">
            About Mach Feeds
          </h1>
          <p className="max-w-2xl text-lg leading-8 text-gray-200">
            Committed to quality animal nutrition and supporting
            livestock farmers.
          </p>
        </div>
      </section>

      <section className="section-padding">
        <div className="container grid items-center gap-12 lg:grid-cols-2">
          <div>
            <p className="mb-3 font-bold uppercase tracking-widest text-harvest">
              Who We Are
            </p>
            <h2 className="mb-6 text-3xl font-extrabold text-brand">
              Think Quality? Think Mach Feeds.
            </h2>
            <p className="mb-5 leading-8 text-gray-600">
              Mach Feeds Limited is an animal feeds manufacturing
              company established in 2000. We are committed to
              providing quality animal nutrition solutions to
              support livestock farmers and the agricultural sector.
            </p>
            <p className="leading-8 text-gray-600">
              Our product range includes feeds for different animal
              species, raw materials and nutritional supplements.
              We also provide consultation and distribution services.
            </p>
          </div>

          <div className="rounded-2xl bg-gray-50 p-10">
            <div className="mb-6 flex h-16 w-16 items-center justify-center rounded-xl bg-brand text-harvest">
              <Award size={34} />
            </div>
            <h3 className="mb-4 text-2xl font-bold text-brand">
              Our Commitment
            </h3>
            <p className="leading-8 text-gray-600">
              We strive to provide dependable animal nutrition
              products and services that contribute to healthier
              livestock and improved productivity.
            </p>
          </div>
        </div>
      </section>

      <section className="section-padding bg-gray-50">
        <div className="container grid gap-7 md:grid-cols-3">
          <div className="rounded-xl bg-white p-8 shadow-sm">
            <Target size={35} className="mb-5 text-harvest" />
            <h3 className="mb-4 text-xl font-bold text-brand">
              Our Mission
            </h3>
            <p className="leading-7 text-gray-600">
              To provide quality animal nutrition solutions that
              support livestock farmers and agricultural productivity.
            </p>
          </div>

          <div className="rounded-xl bg-white p-8 shadow-sm">
            <Eye size={35} className="mb-5 text-harvest" />
            <h3 className="mb-4 text-xl font-bold text-brand">
              Our Vision
            </h3>
            <p className="leading-7 text-gray-600">
              To be a trusted name in animal nutrition and a reliable
              partner to the livestock industry.
            </p>
          </div>

          <div className="rounded-xl bg-white p-8 shadow-sm">
            <HeartHandshake size={35} className="mb-5 text-harvest" />
            <h3 className="mb-4 text-xl font-bold text-brand">
              Our Values
            </h3>
            <p className="leading-7 text-gray-600">
              Quality, reliability, customer commitment and
              continuous improvement guide our work.
            </p>
          </div>
        </div>
      </section>
    </>
  )
}

export default About
